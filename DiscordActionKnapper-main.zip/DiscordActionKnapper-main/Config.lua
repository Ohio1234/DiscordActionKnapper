Config = {}
Config.Buttons = {
    {index = 0,name = '%Website%',url = 'https://www.google.com'},
    {index = 1,name = '%Connect%',url = 'fivem://connect/MyIpAddress:30120'}
}